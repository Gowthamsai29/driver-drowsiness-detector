#include <bits/stdc++.h>
using namespace std;

void generate_random_bits(string &rand_bits, int total_bits)
{
    rand_bits.clear();
    for (int i = 0; i < total_bits; i++)
    {
        rand_bits += (rand() % 2) ? '1' : '0';
    }
}

void bit_stuffing(string &stuffed_bits, const string &input_bits)
{
    int count = 0;
    stuffed_bits.clear();
    for (char bit : input_bits)
    {
        stuffed_bits += bit;
        if (bit == '1')
        {
            count++;
            if (count == 5)
            {
                stuffed_bits += '0';
                count = 0;
            }
        }
        else
        {
            count = 0;
        }
    }
}

int main()
{
    srand(time(NULL));

    int seq_len = 25;
    string original_seq;
    string bit_stuff;

    string original_seq1 = "1100011001000111111001010";
    generate_random_bits(original_seq, seq_len);
    cout << "Original bits: " << original_seq << "\n";

    bit_stuffing(bit_stuff, original_seq);
    cout << "Bit stuffed: " << bit_stuff << "\n";

    return 0;
}
